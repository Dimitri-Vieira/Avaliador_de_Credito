### Requerimentos

* Docker
* Docker Compose

A versão Windows instala o docker, o compose e o Desktop

### Execução

Para executar, abra a pasta no Terminal e digite:

```cmd
docker compose up -d
```